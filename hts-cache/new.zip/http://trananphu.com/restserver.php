
    <!-- BEGIN incHeader -->
        <!DOCTYPE HTML>
<html itemscope itemtype="http://schema.org/WebPage" xmlns:og="http://ogp.me/ns#">
<head>
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <!--<meta name="viewport" content="width=device-width, initial-scale=1" />-->

    <link href="http://www.trananphu.com/favicon.png" rel="shortcut icon" type="image/x-icon" />
    <title>Báo lỗi | Trân An Phú</title>
    <meta property="og:title" content="Báo lỗi | Trân An Phú" name="title" />
    <meta content="" name="keywords" itemprop="keywords" />
    <meta content="" name="description" property="og:description" itemprop="description" />
    <meta property="og:image" itemprop="thumbnailUrl" content="" />

    <!-- bootstrap -->
    <link href="http://www.trananphu.com/theme/css/bootstrap.min.css" rel="stylesheet" />
    <!-- my style -->
    <link href="http://www.trananphu.com/theme/style/style.css" rel="stylesheet" type="text/css" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <script type="text/javascript" src="http://www.trananphu.com/theme/js/jquery.min.js"></script>
    <script type="text/javascript" src="http://www.trananphu.com/theme/js/bootstrap-carousel.js"></script>

    <link rel="stylesheet" type="text/css" href="http://www.trananphu.com/theme/js/jQuerySliderEvolution/slider/themes/fresh/jquery.slider.css" />
    <script type="text/javascript" src="http://www.trananphu.com/theme/js/jQuerySliderEvolution/slider/jquery.slider.min.js"></script>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            $(".slider").slideshow({
                width      : 300,
                height     : 190,
                timer         : false,
                control       : false,
                navigation    : false,
                transition : 'SquareRandom'
            });
        });
    </script>

    <link rel="stylesheet" type="text/css" href="http://www.trananphu.com/theme/css/show3d.css" />
    <script type="text/javascript" src="http://www.trananphu.com/theme/js/modernizr.custom.53451.js"></script>
    <script type="text/javascript" src="http://www.trananphu.com/theme/js/jquery.gallery.js"></script>
    <script type="text/javascript">
        $(function() {
            $("#dg-container").gallery({
                autoplay	:	true
            });
        });
    </script>
    <!-- *shtv -->
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            $(".sliderPr").slideshow({
                width      : 300,
                height     : 260,
                timer         : false,
                control       : false,
                navigation    : false,
                selector      : false,
                bars          : 5,
                columns       : 3,
                padding       : 4,
                duration      : 500,
                speed         : 200,
                pauseOnHover  : false,
                delay         : 3000,
                transition    : 'fade'
            });
            $(".sliderBanner").slideshow({
                width      : 1000,
                height     : 230,
                timer         : false,
                control       : true,
                navigation    : true,
                selector      : true,
                bars          : 5,
                columns       : 1,
                padding       : 4,
                duration      : 500,
                speed         : 200,
                pauseOnHover  : false,
                delay         : 3000,
            });
        });
    </script>
    <!-- /*shtv -->
</head>
<body>
<header id="header">
    <div class="wrapper">
        <div id="logo-box">
            <img src="http://www.trananphu.com/theme/images/logo.png" alt="Logo">
            <div id="company-name-box">
                <h3>Thuốc Thú Y - Thủy Sản</h3>
                <h1>Trân An Phú</h1>
                <div class="clear"></div>
            </div>
        </div>
        <form id="form-search" role="search" action="http://www.trananphu.com/product/search" method="GET">
            <input type="text" name="keyword" placeholder="Từ khóa tìm kiếm" />
        </form>
        <div class="clear"></div>
        <div id="site-nav">
            <ul>
                <li><a class="" href="http://www.trananphu.com">Trang chủ</a></li>
                <li><a class="" href="http://www.trananphu.com/san-pham/">Sản phẩm</a></li>
                <li><a class="" href="http://www.trananphu.com/ban-tin/">Kỹ thuật</a></li>
                <li><a class="" href="http://www.trananphu.com/tuyen-dung/">Tuyển dụng</a></li>
                <li><a class="" href="http://www.trananphu.com/user/">Thành viên</a></li>
                <li><a class="" href="http://www.trananphu.com/trang/lien-he/">Liên hệ</a></li>
            </ul>
        </div>
    </div>
</header>
<div class="clearfix"></div>
<!-- END incHeader -->
<section class="wrapper">
    <div id="banner">
        <div class="sliderBanner">
            
            <div>
                <img src="http://www.trananphu.com/upload/slide/banner2.png" alt="" />
            </div>
            
            <div>
                <img src="http://www.trananphu.com/upload/slide/banner2.jpg" alt="" />
            </div>
            
            <div>
                <img src="http://www.trananphu.com/upload/slide/banner4.jpg" alt="" />
            </div>
            
            <div>
                <img src="http://www.trananphu.com/upload/slide/banner5.jpg" alt="" />
            </div>
            
            <div>
                <img src="http://www.trananphu.com/upload/slide/banner1.jpg" alt="" />
            </div>
            
            <div>
                <img src="http://www.trananphu.com/upload/slide/banner3.jpg" alt="" />
            </div>
            
        </div>
    </div>
    <!-- END incHeader -->
    <!-- END incHeader -->
    <div id="midle">
        <div class="wraper">
            <div style="text-align: center;">
                <p>
                    Xin lỗi trang bạn vừa truy cập không có.  Rất tiếc vì sự bất tiện này, vui lòng về lại <a href="http://www.trananphu.com"> trang chủ</a>.
                </p>
                <img alt="404" src="http://www.trananphu.com/theme/images/error404.png" />
                <span style="text-transform: uppercase; display: block; margin-top: 10px;"><a href="http://www.trananphu.com">Trang chủ</a> | <a href="http://www.trananphu.com/page/contact">Liên hệ</a></span>
            </div>
        </div>    <!-- End wraper -->
    </div> <!-- END MIDLE -->
    <!-- BEGIN incFooter -->
        </section>
<!-- BEGIN incFooter -->
<div class="clear"></div>
<footer id="footer">
    <div class="wrapper">      
        <div class="details">
            <h4 class="cty">TRAN AN PHU CO.,LTD</h4>
            <span class="city">Đ/c: 97/14/4 Ung Văn Khiêm, P25, Quận Bình Thạnh, TP Hồ Chí Minh</span><br />
            <span class="phone">0127 369 2277</span><br />
            <span class="email">trananphu2010@gmail.com</span><br />
        </div>
        <div class="social">
            <img src="http://www.trananphu.com/theme/images/social-facebook.png" alt="" />
            <p>/trananphu</p>
        </div>
        <div class="social">
            <img src="http://www.trananphu.com/theme/images/social-google.png" alt="" />
            <p>/trananphu</p>
        </div>
        <div class="social">
            <img src="http://www.trananphu.com/theme/images/social-tweet.png" alt="" />
            <p>/trananphu</p>
        </div>
        <div class="clear"></div>
    </div><!-- //details -->

    <div class="wrap-copy-right copy-right">
        <p>TranAnPhu.com, All right reserved</p>
    </div><!-- //copy-right -->
</footer>

<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>-->

<script>
    $('.carousel').carousel({
        interval: 2000
    });
</script>

<script type="text/javascript">
    window.___gcfg = {lang: 'vi'};

    (function() {
        var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
        po.src = 'https://apis.google.com/js/platform.js';
        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
    })();
</script>
<div id="fb-root"></div>
<script>(function(d, s, id) {
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) return;
    js = d.createElement(s); js.id = id;
    js.src = "//connect.facebook.net/vi_VN/all.js#xfbml=1";
    fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<script>
    !function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="https://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");
</script>

</body>
</html>
<!-- END incFooter -->
    <!-- END incFooter -->
